$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("./src/main/resources/feature/test.feature");
formatter.feature({
  "line": 2,
  "name": "ProductStore  Website",
  "description": "",
  "id": "productstore--website",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@Project_ProductStore"
    }
  ]
});
formatter.scenarioOutline({
  "line": 4,
  "name": "verify the title of the webapplication",
  "description": "",
  "id": "productstore--website;verify-the-title-of-the-webapplication",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 3,
      "name": "@TC01_Project_ProductStore"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "launching the application and login \u003cusername\u003e and \u003cpassword\u003e into the application and",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "the user is on home page,take out the title and compare",
  "keyword": "When "
});
formatter.examples({
  "line": 7,
  "name": "",
  "description": "",
  "id": "productstore--website;verify-the-title-of-the-webapplication;",
  "rows": [
    {
      "cells": [
        "username",
        "",
        "password"
      ],
      "line": 8,
      "id": "productstore--website;verify-the-title-of-the-webapplication;;1"
    },
    {
      "cells": [
        "sushmitha",
        "",
        "sushmitha1"
      ],
      "line": 9,
      "id": "productstore--website;verify-the-title-of-the-webapplication;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 9,
  "name": "verify the title of the webapplication",
  "description": "",
  "id": "productstore--website;verify-the-title-of-the-webapplication;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 3,
      "name": "@TC01_Project_ProductStore"
    },
    {
      "line": 1,
      "name": "@Project_ProductStore"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "launching the application and login sushmitha and sushmitha1 into the application and",
  "matchedColumns": [
    0,
    2
  ],
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "the user is on home page,take out the title and compare",
  "keyword": "When "
});
formatter.match({
  "arguments": [
    {
      "val": "sushmitha",
      "offset": 36
    },
    {
      "val": "sushmitha1",
      "offset": 50
    }
  ],
  "location": "Title_TestCase.beforeAll(String,String)"
});
formatter.result({
  "duration": 57632300600,
  "status": "passed"
});
formatter.match({
  "location": "Title_TestCase.after()"
});
formatter.result({
  "duration": 20914229900,
  "status": "passed"
});
});